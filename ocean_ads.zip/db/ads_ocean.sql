-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2023 at 07:22 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ads_ocean`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_add_data`
--

CREATE TABLE `tbl_add_data` (
  `id` int(11) NOT NULL,
  `ads_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `smart_banner` text NOT NULL,
  `banner` text NOT NULL,
  `full_page` text NOT NULL,
  `video` text NOT NULL,
  `app_open` text NOT NULL,
  `medium_rectangle` text NOT NULL,
  `status` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_add_data`
--

INSERT INTO `tbl_add_data` (`id`, `ads_id`, `app_id`, `smart_banner`, `banner`, `full_page`, `video`, `app_open`, `medium_rectangle`, `status`, `last_update`) VALUES
(2, 1, 1, 'test123', 'tes213', 'fdgfdg', 'https://www.youtube.com/embed/aZ_ww6ucBC0?si=8Ajo3qeDiSGkwmJo', 'dfgfd', 'fgdfg', 'facebook_active', '2023-10-04 08:05:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `is_active` char(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `email`, `password`, `is_active`, `created_at`, `modified_at`) VALUES
(1, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '1', '2018-12-29 06:40:08', '2023-07-04 10:22:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ads_cat`
--

CREATE TABLE `tbl_ads_cat` (
  `id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `status` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_ads_cat`
--

INSERT INTO `tbl_ads_cat` (`id`, `name`, `status`, `last_update`) VALUES
(1, 'test', 'Active', '2023-10-04 04:46:35'),
(2, 'demo', 'Active', '2023-10-04 04:48:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app_cat`
--

CREATE TABLE `tbl_app_cat` (
  `id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `status` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_app_cat`
--

INSERT INTO `tbl_app_cat` (`id`, `name`, `status`, `last_update`) VALUES
(1, 'test app', 'Active', '2023-10-04 05:03:02'),
(2, 'demo app', 'Active', '2023-10-04 08:06:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_add_data`
--
ALTER TABLE `tbl_add_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ads_cat`
--
ALTER TABLE `tbl_ads_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_app_cat`
--
ALTER TABLE `tbl_app_cat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_add_data`
--
ALTER TABLE `tbl_add_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_ads_cat`
--
ALTER TABLE `tbl_ads_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_app_cat`
--
ALTER TABLE `tbl_app_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
