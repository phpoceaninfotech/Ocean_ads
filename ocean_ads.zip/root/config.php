<?php
/*
	File = config.php
	Date = 22-2-2018
*/
// session start
session_start();
error_reporting(0);
// website full url
define('SITE_LOCAL_URL','http://localhost/qr-ocean_ads/');
//define('SITE_LIVE_URL','http://lionaircompressor.com/');

// site running in live server or locaL
define('SITE_MODE','0');
define('DB_PREFIX','tbl_');
define('SITE_TITLE','Ocean Infotech');
define('SITE_EMAIL','info@mail.com');
define('SITE_PHONE','+91 9999999999');
define('SITE_ADDRESS','Address');

// live db configuration
$bc_live_host = 'localhost';
$bc_live_user = 'ads_ocean';
$bc_live_pass = 'ads_ocean@15892';
$bc_live_db = 'ads_ocean';
// local db configuration
$bc_host = 'localhost';
$bc_user = 'root';
$bc_pass = '';
$bc_db = 'ads_ocean';
// other configuration
if( SITE_MODE == 0 )
{
	define('SITE_URL', SITE_LOCAL_URL);
	define('ADMIN_URL', SITE_LOCAL_URL.'ocean_ads/');
	// db configuration
	define('DB_HOST', $bc_host);
	define('DB_USER', $bc_user);
	define('DB_PASS', $bc_pass);
	define('DB_DATABASE', $bc_db);
}
else
{
	define('SITE_URL', SITE_LIVE_URL);
	define('ADMIN_URL', SITE_LIVE_URL.'ocean_ads/');
	// db configuration
	define('DB_HOST', $bc_live_host);
	define('DB_USER', $bc_live_user);
	define('DB_PASS', $bc_live_pass);
	define('DB_DATABASE', $bc_live_db);
//	mysql_connect(DB_HOST,DB_USER,DB_PASS) or die(mysql_error());die; 
}
// Error Message
define('INSERT_MSG','Record added successfully!');
define('UPDATE_MSG','Record updated sucessfully!');
define('DELETE_MSG','Record deleted successfully!');
define('ACTIVE_MSG','User activated successfully!');
define('DEACTIVE_MSG','User deactivated successfully!');
define('MDELETE_MSG','Selected record deleted successfully!');
define('MACTIVE_MSG','Selected record activated successfully!');
define('MDEACTIVE_MSG','Selected record deactivated successfully!');
// class call function
date_default_timezone_set('Asia/Calcutta');
require_once("ai_core/class.core.php");
require_once('include/class.phpmailer.php');
?>